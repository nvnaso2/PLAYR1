import{cT as i}from"./index-nDVQm8tW.js";const t=i("PushNotifications",{});export{t as PushNotifications};
