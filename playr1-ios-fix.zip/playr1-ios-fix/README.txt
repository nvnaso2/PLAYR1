PLAYR1 iOS Update - Fix Package
================================

STEP 1 - Replace capacitor.config.json on your laptop:
  native-files/capacitor.config.json  ->  ios/App/App/capacitor.config.json

STEP 2 - Fix the public folder in Xcode (IMPORTANT):
  The public folder must be added as a folder REFERENCE in Xcode (not a group).
  See instructions below.

STEP 3 - Replace public folder contents:
  Delete everything inside:  ios/App/App/public/
  Copy everything from:      public-folder/  into  ios/App/App/public/

STEP 4 - In Xcode: Product > Clean Build Folder, then Run or Archive

HOW TO FIX THE PUBLIC FOLDER IN XCODE:
1. Open App.xcworkspace in Xcode
2. In the left panel (Project Navigator), expand App > App
3. Look for a "public" entry - if it has a YELLOW folder icon, delete it from Xcode only (not from disk)
4. Right-click on the inner "App" folder in the navigator
5. Choose "Add Files to App..."
6. Navigate to and select the public folder (ios/App/App/public)
7. CRITICAL: At the bottom of the dialog, select "Create folder references" (NOT "Create groups")
   - You want a BLUE folder icon, not yellow
8. Make sure "Add to targets: App" is checked
9. Click Add
10. Product > Clean Build Folder, then run/archive
