import{cT as i}from"./index-DU0zO5LU.js";const t=i("PushNotifications",{});export{t as PushNotifications};
