import{cT as i}from"./index-tDjz91sE.js";const t=i("PushNotifications",{});export{t as PushNotifications};
