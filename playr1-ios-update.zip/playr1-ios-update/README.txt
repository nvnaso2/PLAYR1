PLAYR1 iOS Update Package
=========================

STEP 1 - Replace native config files on your laptop:

  native-files/capacitor.config.json        -> ios/App/App/capacitor.config.json
  native-files/AppDelegate.swift            -> ios/App/App/AppDelegate.swift
  native-files/Base.lproj/Main.storyboard  -> ios/App/App/Base.lproj/Main.storyboard

  ALSO DELETE this file if it exists on your laptop:
  ios/App/App/ViewController.swift

STEP 2 - Replace the public folder:

  Delete everything inside:  ios/App/App/public/
  Copy everything from:      public-folder/  into  ios/App/App/public/

STEP 3 - Archive in Xcode:

  Open ios/App/App.xcworkspace
  Product > Archive > Distribute App > TestFlight

FUTURE UPDATES (no native file changes needed ever again):
  Just repeat Steps 2 and 3 with a new build.
