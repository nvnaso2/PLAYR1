import{cT as i}from"./index-DwDjKH1z.js";const t=i("PushNotifications",{});export{t as PushNotifications};
