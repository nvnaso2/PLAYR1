import{cT as i}from"./index-CenjsegW.js";const t=i("PushNotifications",{});export{t as PushNotifications};
