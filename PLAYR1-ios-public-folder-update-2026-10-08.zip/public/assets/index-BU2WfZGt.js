import{dv as i}from"./index-DHoVpaoe.js";const t=i("PushNotifications",{});export{t as PushNotifications};
