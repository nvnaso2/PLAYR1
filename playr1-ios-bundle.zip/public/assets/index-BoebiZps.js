import{cT as i}from"./index-BV7WTgbm.js";const t=i("PushNotifications",{});export{t as PushNotifications};
