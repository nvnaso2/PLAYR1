const o="/assets/Playr1_App_Logo_1773593823443-AnC8ou5s.png";export{o as p};
