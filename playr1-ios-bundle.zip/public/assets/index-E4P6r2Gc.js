import{cT as i}from"./index-DNcsg103.js";const t=i("PushNotifications",{});export{t as PushNotifications};
