import{cT as i}from"./index-CJ9NB1G0.js";const t=i("PushNotifications",{});export{t as PushNotifications};
