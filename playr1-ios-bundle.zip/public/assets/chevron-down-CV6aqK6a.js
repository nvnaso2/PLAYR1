import{c as o}from"./index-CJ9NB1G0.js";const n=o("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);export{n as C};
