PLAYR1 iOS - Local Bundle Setup
================================

This is the FINAL, clean setup. No remote URL. App runs from local files.
No Safari redirect possible.

STEP 1 - Replace these files on your laptop:

  native-files/capacitor.config.ts         -> playr1-source/capacitor.config.ts
  native-files/capacitor.config.json       -> playr1-source/ios/App/App/capacitor.config.json
  native-files/AppDelegate.swift           -> playr1-source/ios/App/App/AppDelegate.swift
  native-files/Main.storyboard             -> playr1-source/ios/App/App/Base.lproj/Main.storyboard

  DELETE this file if it exists:
  playr1-source/ios/App/App/ViewController.swift

STEP 2 - Replace the public folder:

  You already ran npm run build so dist/public/ has fresh files.
  Delete everything inside:  playr1-source/ios/App/App/public/
  Copy everything from:      playr1-source/dist/public/   into it

STEP 3 - Make sure public folder is in Xcode build:

  In Xcode left sidebar: App > App > public
  It should be a BLUE folder icon.
  If not, right-click App folder > Add Files > select public > Create folder references > Add

STEP 4 - Xcode: Product > Clean Build Folder > Run (or Archive for TestFlight)

FUTURE UPDATES:
  1. Make changes on Replit
  2. npm run build  (on your Mac in playr1-source/)
  3. Copy dist/public/ contents into ios/App/App/public/
  4. Archive in Xcode > TestFlight
