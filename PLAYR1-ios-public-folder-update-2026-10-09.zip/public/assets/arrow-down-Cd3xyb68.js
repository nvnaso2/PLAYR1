import{h as o}from"./index-BfZH5w_Y.js";const r=o("ArrowDown",[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]]);export{r as A};
