function r(t){return t==="pro"||t==="pro-infinity"?null:3}function u(t,n){return n!==null&&t>=n}function i(t){return t.reduce((n,o)=>n+(o.isAssigned?0:1),0)}export{i as c,r as g,u as i};
