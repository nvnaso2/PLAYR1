import{j as t,V as e}from"./index-DgPYRNbp.js";function a(){return t.jsx(e,{to:"/archetypes?tab=identity"})}export{a as default};
