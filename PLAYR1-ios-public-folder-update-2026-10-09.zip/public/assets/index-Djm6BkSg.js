import{dv as i}from"./index-BfZH5w_Y.js";const t=i("PushNotifications",{});export{t as PushNotifications};
