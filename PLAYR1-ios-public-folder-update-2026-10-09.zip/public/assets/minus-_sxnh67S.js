import{h as s}from"./index-DgPYRNbp.js";const e=s("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{e as M};
