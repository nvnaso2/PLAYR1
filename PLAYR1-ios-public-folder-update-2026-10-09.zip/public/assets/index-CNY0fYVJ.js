import{dv as i}from"./index-DgPYRNbp.js";const t=i("PushNotifications",{});export{t as PushNotifications};
