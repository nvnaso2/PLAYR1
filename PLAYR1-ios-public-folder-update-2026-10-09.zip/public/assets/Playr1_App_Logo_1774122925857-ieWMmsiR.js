const o="/assets/Playr1_App_Logo_1774122925857-AnC8ou5s.png";export{o as p};
